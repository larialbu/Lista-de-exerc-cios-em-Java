import java.util.Scanner;

public class tesste {
    public static void main(String[] args) {
        int filho, contM = 0,cont = 0, somaf = 0;
        double salario, somas = 0, perc = 0, ms = 0 , mf = 0, maiorSS = 0;
        char SFilho;
        char fim = 0;
        Scanner s = new Scanner(System.in);
        // a media de salario ok;
        // media de filhos ok;
        // maior salario m ok;
        // percentual de pessoas com salario ate R$ 900,00 ok;

        do {
            System.out.println("Essa pesquisa quer os filhos e o salario ");
            System.out.printf("Digite o seu salario: ");
            salario= s.nextDouble();

            System.out.printf("Tem filhos [s/n]: ");
            SFilho  = s.next().charAt(0);


            if (SFilho == 's'){
                System.out.printf("Quantos filhos: ");
                filho = s.nextInt();
                System.out.printf("Quer continuar digite [s/n]: ");
                fim = s.next().charAt(0);

                cont = cont +1 ;

                somas = salario + somas ;
                somaf = filho + somaf ;
                if (salario > maiorSS){
                    maiorSS =  maiorS(salario);
                }

                if (salario < 900.00){
                    contM = contM + 1;
                }
                perc = percen(contM,cont);


            }
            else {
                System.out.printf("Quer continuar ? [s/n] ");
                fim =s.next().charAt(0);
                cont = cont +1 ;
            }

        } while (fim == 's');
        perc = percen(contM,cont);
        ms = msalario(somas,cont);
        mf = mfilhos(somaf, cont);


        System.out.println("========================================");
        System.out.println("O maior salario foi " + maiorSS);
        System.out.println("A media de salario e de:" + ms);
        System.out.println("A porcentagem de salario menor que R$ 900,00 e de: " + perc);
        System.out.println("A media de filhos e de: " + mf);
        System.out.println("========================================");

    }
    //media de filhos
    public static double mfilhos(double x1, double x2){
        double mfi = 0;
        mfi = x1 / x2;
        return mfi;
    }
    // media de salario
    public static double msalario(double x1, double x2){
        double msal = 0;
        msal = x1 / x2;
        return msal;
    }
    //percentual
    public static double percen(double x1, double x2) {
        double  per = 0;
        per = (x1*100)/x2;
        return per;
    }
    //maior salario
    public static double maiorS(double x) {

        double mSalario = 0 ;
        mSalario = x ;
        return mSalario ;
    }

}
