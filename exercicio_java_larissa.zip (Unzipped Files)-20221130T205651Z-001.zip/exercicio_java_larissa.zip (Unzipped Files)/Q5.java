public class MyClass {

    public static void main(String args[]) {

      int ini;
      int numero = 7;
      int resultado;


      for (ini = 10; ini <= 25; ini++) {

        resultado = numero * ini;

      System.out.println(numero +  " * "+ ini + " = " +  resultado + "\n"); 

    }  
    }

}

