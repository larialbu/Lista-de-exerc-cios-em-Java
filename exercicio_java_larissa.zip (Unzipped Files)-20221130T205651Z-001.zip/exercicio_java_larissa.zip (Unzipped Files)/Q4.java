import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
	    int valor = 0;
	    int quantPositivo = 0;
	    int maiorPositivo = 0;
	    int menorNegativo = 0;
	    int i;
	    
	    Scanner scnr = new Scanner(System.in);
	    
		for (i = 0; i <= 50; i++) {
            System.out.println("Digite o valor");
		    valor = scnr.nextInt();
		    
		    if(i == 0){
		        menorNegativo = valor;
		    }
		    
		    if (valor >= 0){
		        quantPositivo = quantPositivo + 1;
		        if(valor > maiorPositivo){
		            maiorPositivo = valor;
		            
		        }else if(valor < menorNegativo){
		            menorNegativo = valor;
		        }
		        
		    }
		    
		   

        }  
        System.out.println("quantidade de positivos: " + quantPositivo);
	    System.out.println("maior positivo: " + maiorPositivo);
	    System.out.println("menor valor: " + menorNegativo);
	}
}