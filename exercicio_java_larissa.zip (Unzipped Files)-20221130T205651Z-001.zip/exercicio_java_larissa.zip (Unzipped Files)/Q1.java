import java.util.Scanner;

public class Main{

	public static void main(String[] args) {
		int n1, n2, n3 = 0;
		double resultado;
		
		String letra = "";
		
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("Digite a nota1");
		n1 = scnr.nextInt();
		
		System.out.println("Digite a nota2");
		n2 = scnr.nextInt();
		
		System.out.println("Digite a nota3");
		n3 = scnr.nextInt();
		
		System.out.println("Digite a letra");
		letra = scnr.next();
		
		if(letra.equals("A")){
			resultado = (n1 + n2 + n3)/3;
			System.out.println("A media aritimetica é: " + resultado);
			resultadoMedia(resultado);
			
		}else if(letra.equals("P")){
			resultado = ((n1 * 2) + (n2 * 4) + (n3 * 6))/12;
			System.out.println("A media ponderada é: "+ resultado);
		    resultadoMedia(resultado);
		    
		}
		
		scnr.close();
	}
	
	public static void resultadoMedia(double resultado) {
        if(resultado >= 0 && resultado <= 4.9){
            // conceito d
            System.out.println("conceito D");
		    
		}else if(resultado >= 5.0 && resultado <= 6.9){
		    // conceito C
            System.out.println("conceito C");
		    
		}else if(resultado >= 7.0 && resultado <= 8.9){
		    // conceito B
            System.out.println("conceito B");
		    
		}else if(resultado >= 9.0 && resultado <= 10.0){
		    // conceito A
            System.out.println("conceito A");
		    
		}else{
		    System.out.println("não foi possivel calcular seus conceitos");
		    
		}
        
    }
}