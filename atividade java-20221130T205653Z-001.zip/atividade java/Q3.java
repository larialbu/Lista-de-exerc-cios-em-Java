import java.util.Scanner;

public class Q3 {
 public static void main(String args[]) {
  Scanner entrada = new Scanner(System.in);
  double maior = -2000, menor = 2000;
  int quente=0,frio=0;

  double temperatura[] = new double[12];

  for (int i = 0; i < temperatura.length; i++) {
   System.out.println("Diga a temperatura do mês"+(i+1));
   temperatura[i] = entrada.nextDouble();
 
    if (temperatura[i] >= maior) {
     maior=temperatura[i];
     quente = i;
     //System.out.println("x"+maior);
    } if (temperatura[i] <= menor){
     menor=temperatura[i];
    frio = i;}
    //System.out.println("x"+menor);
    
   }
  

  System.out.println("A maior temperatura ocorre no mês "+(quente+1)+", a temperatura doi de" + maior + "º e a menor ocorreu no mês"+(frio+1)+", a temperatura foi "+menor);
 }
}