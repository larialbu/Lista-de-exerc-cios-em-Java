import java.util.Scanner;
import java.util.Arrays;

public class Q4{
	public static void main(String args[]){
	    Scanner read = new Scanner(System.in);

	    Int v[] = new Int[10];
	    Int v1[] = new Int[5];

		for (i=0;i < 10;i++){
        	System.out.println("Escreva 10 números");
        	v[i]=read.nextLine();
        	v1[i]=read.nextLine();
        }
      Arrays.sort(v1[i]);

      System.out.println("Os 5 números, postos ordenadamente, são esses:");
      

    }    
}
	   