// Faça um programa que preencha um vetor //com nove números inteiros, calcule 
//e mostre os números ímpares e suas 
//respectivas posições.
import java.util.Scanner;

public class Q1{
	public static void main(String[] args) {
			Scanner read = new Scanner(System.in);

		

		int i;
		int count [ ] = new int[9];
		int v [ ] = new int [9];

		int primo[ ] = new int [9];
		
		for (i=0; i<10; i++) {

      	System.out.println("Digite 9 valores:");

           v[i] = read.nextInt();

                     if (v[i] %2!=0){
                     count[i]= i;
                     }    	
     	}
       System.out.println("Todos os valores impares são" + primo[i]+"e suas respectivas posições no vetor são"+ count[i]);

      
	}
}