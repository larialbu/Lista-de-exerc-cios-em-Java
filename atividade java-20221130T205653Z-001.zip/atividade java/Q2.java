import java.util.Scanner;
import java.util.Arrays;

public class Q1{
	public static void main(String[] args) {
		Scanner read = new Scanner(System.in);

		int i;
		int v[] = new Int[8];
		int v1[] = new Int[8];
		int v2[] = new Int[8];
        
        for (i=0;i < 8;i++){
        	System.out.println("Escreva 8 números. Podem ser negativo ou positivo.");
        	v[i]=read.nextLine();
        	If(v[i] < 0){
        		v1[i]=read.nextLine(v[i]);
        	}If (v[i] >=0){
        	v2[i]=read.nextLine(v[i]);
        	} 	
        }

        System.out.println("Os números positivos são:");
        System.out.println(v2[i]);
        System.out.println("e os negativos são:");
        System.out.println(v1[i]);


   }
}
